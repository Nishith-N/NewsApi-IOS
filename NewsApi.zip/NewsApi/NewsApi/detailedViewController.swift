//
//  detailedViewController.swift
//  NewsApi
//
//  Created by Anil Kumar on 04/01/23.
//

import UIKit

class detailedViewController: UIViewController {
  @IBOutlet weak var titleLabel: UILabel!
  
  @IBOutlet weak var contentLabel: UILabel!
  
  @IBOutlet weak var webBtn: UIButton!
  @IBOutlet weak var bgDetail: UIImageView!
  
  @IBOutlet weak var authorLabel: UILabel!
  
  var recTitle : String!
  var recImage : String!
  var recAuth: String!
  var recURL: String!
  var recCont: String!
    override func viewDidLoad() {
        super.viewDidLoad()

      
      titleLabel.text = recTitle
      authorLabel.text = recAuth
      contentLabel.text = recCont
      
      
      
      
      
      webBtn.clipsToBounds = true
      webBtn.layer.cornerRadius = 15
      
      if let url = URL(string: recImage ) {
              let task = URLSession.shared.dataTask(with: url) { data, response, error in
                  guard let data = data, error == nil else { return }
      
                  DispatchQueue.main.async {
      
                    
                    self.bgDetail.image = UIImage(data: data)
                            
                  }
              }
      
              task.resume()
          }
             }
  
    
  @IBAction func didTap(_ sender: Any) {
    UIApplication.shared.open(URL(string: recURL)!)
  }
  
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
