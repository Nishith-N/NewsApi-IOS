//
//  ViewController.swift
//  NewsApi
//
//  Created by Anil Kumar on 04/01/23.
//

import UIKit
import Kingfisher

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
  
  var sendTitle : String!
  var sendImage: String!
  var sendAuth: String!
  var sendURL: String!
  var sendCont: String!
  
  var newData = [String:Any]()
  var wholeData = [[String:Any]]()

  @IBOutlet weak var dataTableView: UITableView!
  override func viewDidLoad() {
    super.viewDidLoad()
    
    
    dataTableView.delegate = self
    dataTableView.dataSource = self
    
    getMethodAPI()
    // Do any additional setup after loading the view.
  }
  
  func getMethodAPI() {
      
      let url = URL(string: "https://newsapi.org/v2/everything?q=apple&from=2023-01-03&to=2023-01-03&sortBy=popularity&apiKey=05c61ae9507642089baa70efcf161f21")
      var urlReq = URLRequest(url: url!)
      urlReq.httpMethod = "GET"
      
    let task = URLSession.shared.dataTask(with: urlReq) { [self] (data, response, error) in
          if let err = error{
            
              print(err)
            print("hello")
              return
          }
          if let resp = response as? HTTPURLResponse{
              print(resp.statusCode)
          }
          do{
            newData = try JSONSerialization.jsonObject(with: data!, options: []) as! [String: Any]
            
            wholeData = newData["articles"] as! [[String:Any]]
            print(wholeData[0]["author"]!)
            
  
          }
        
          catch let err as NSError{
              print(err.localizedDescription)
          }
          DispatchQueue.main.async {
              self.dataTableView.reloadData()
          }
          
      }
      task.resume()
  }
  
  
  
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return wholeData.count
  }
  
  
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "customTableViewCell", for: indexPath) as! customTableViewCell
   
    cell.bgImage.image = nil
    cell.tag = indexPath.row
    cell.authorLbl.text = wholeData[indexPath.row]["author"]  as? String ?? ""
    cell.TitleLbl.text = wholeData[indexPath.row]["title"] as? String
    cell.descLbl.text = wholeData[indexPath.row]["description"] as? String
    
//    if let url = URL(string: (wholeData[indexPath.row]["urlToImage"] as? String)! ) {
//        let task = URLSession.shared.dataTask(with: url) { data, response, error in
//            guard let data = data, error == nil else { return }
//
//            DispatchQueue.main.async {
//
//              if cell.tag == indexPath.row{
//                          cell.bgImage.image = UIImage(data: data)
//                      }
//            }
//        }
//
//        task.resume()
//    }
    

  

        // Fetch Image for Landscape
    KF.url(URL(string: (wholeData[indexPath.row]["urlToImage"] as? String)!))
            .set(to: cell.bgImage)
    
    return cell
  }
  
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    let vc = storyboard?.instantiateViewController(withIdentifier: "detailedViewController") as! detailedViewController
    
    
    self.sendTitle = wholeData[indexPath.row]["title"] as? String ?? ""
    self.sendImage = wholeData[indexPath.row]["urlToImage"] as? String
    self.sendAuth = wholeData[indexPath.row]["author"] as? String
    self.sendCont = wholeData[indexPath.row]["content"] as? String
    self.sendURL = wholeData[indexPath.row]["url"] as? String
    vc.recTitle = self.sendTitle
    vc.recImage = self.sendImage
    vc.recAuth = self.sendAuth
    vc.recCont = self.sendCont
    vc.recURL = self.sendURL
    
    navigationController?.pushViewController(vc, animated: true)
  }
  
  func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
      return 494
  }


}



