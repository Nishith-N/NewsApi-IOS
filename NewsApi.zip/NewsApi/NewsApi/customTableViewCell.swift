//
//  customTableViewCell.swift
//  NewsApi
//
//  Created by Anil Kumar on 04/01/23.
//

import UIKit

class customTableViewCell: UITableViewCell {

  @IBOutlet weak var descLbl: UILabel!
  @IBOutlet weak var TitleLbl: UILabel!
  @IBOutlet weak var bgImage: UIImageView!
  @IBOutlet weak var authorLbl: UILabel!
  @IBOutlet weak var myView: UIView!
  override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
